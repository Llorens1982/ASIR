<?php    
function recupera($forma)
{
    $datos=$_REQUEST[$forma];
        return $datos;
}
        
    
?>
