SELECT cod_a, descrip, preu, preu * 1.05 
FROM article;