SELECT *
FROM article
WHERE stock_min IS NULL;