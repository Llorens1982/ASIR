SELECT num_f, data, cod_cli, cod_ven, iva, dte
FROM factura
WHERE data BETWEEN '2015-03-01' AND '2015-03-31'