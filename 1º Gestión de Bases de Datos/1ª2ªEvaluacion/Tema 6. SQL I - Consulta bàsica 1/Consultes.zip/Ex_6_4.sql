SELECT INITCAP(nom)||',' ||' '|| adreca ||' '|| '(' || cp ||')'
FROM client