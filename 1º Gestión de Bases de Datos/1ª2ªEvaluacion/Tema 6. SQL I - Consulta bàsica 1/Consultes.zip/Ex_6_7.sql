SELECT cod_cli, nom, adreca, cp, cod_pob
FROM client
WHERE cod_pob = 12309;