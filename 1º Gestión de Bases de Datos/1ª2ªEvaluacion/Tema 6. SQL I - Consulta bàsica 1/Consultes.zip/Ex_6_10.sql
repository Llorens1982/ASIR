SELECT cod_cli, nom, adreca, cp, cod_pob
FROM client
WHERE cp IS NULL;