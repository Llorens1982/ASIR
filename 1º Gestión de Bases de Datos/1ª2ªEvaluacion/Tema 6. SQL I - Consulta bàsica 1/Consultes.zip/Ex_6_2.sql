SELECT cp, nom, adreca 
FROM venedor