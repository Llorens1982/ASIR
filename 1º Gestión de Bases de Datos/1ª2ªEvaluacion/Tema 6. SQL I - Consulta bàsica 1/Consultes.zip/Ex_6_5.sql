SELECT num_f as "Número Factura", data as "data", cod_ven as "Codi Venedor"
FROM factura;
