SELECT cod_pob, nom, cod_pro
FROM poble;
