SELECT cod_a as "Codi Article", descrip as "descripció", preu, stock, stock_min as "Stock mínim", cod_cat as "Codi Categoria"
FROM article;
