SELECT cod_cap 
FROM venedor 
WHERE cod_cap IS NOT NULL 
GROUP BY cod_cap;