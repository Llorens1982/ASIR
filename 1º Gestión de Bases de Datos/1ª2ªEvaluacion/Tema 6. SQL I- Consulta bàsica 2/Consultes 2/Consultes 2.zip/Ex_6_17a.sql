SELECT AVG (stock)
FROM article;