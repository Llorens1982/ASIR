SELECT cod_cli, nom, adreca, cp, cod_pob
FROM client
ORDER BY cod_pob, cp;