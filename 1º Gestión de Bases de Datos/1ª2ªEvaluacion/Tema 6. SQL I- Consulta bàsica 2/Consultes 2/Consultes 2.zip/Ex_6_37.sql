SELECT MAX(stock), MIN(stock), AVG(stock)
FROM article_36;