SELECT COUNT (*)
FROM factura
WHERE cod_cli = 375;