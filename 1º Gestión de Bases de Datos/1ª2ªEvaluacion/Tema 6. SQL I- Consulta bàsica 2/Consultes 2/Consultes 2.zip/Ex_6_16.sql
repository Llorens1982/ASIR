SELECT COUNT (*), SUM (quant) 
FROM linia_fac
WHERE cod_a LIKE 'L76104';