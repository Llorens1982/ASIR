SELECT COUNT(*) 
FROM client
WHERE cp is null;