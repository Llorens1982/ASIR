SELECT cod_ven 
FROM factura 
WHERE TO_CHAR(data,'YYYY-MM')='2015-01' 
GROUP BY cod_ven;