SELECT MAX(dte), MIN(dte), AVG(dte)
FROM factura;