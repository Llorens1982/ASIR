SELECT cod_pob, COUNT (*)
FROM client
GROUP BY cod_pob
HAVING COUNT(cod_cli) BETWEEN 4 AND 7;