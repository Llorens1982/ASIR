SELECT cod_pro, COUNT (*)
FROM poble
GROUP BY cod_pro;