SELECT COALESCE(stock,0)
FROM article
GROUP BY stock
HAVING AVG(stock);